# Game-Development-Project
 ## Purpose of the project:
 ### Create an interactive video game using Processing - Space Invaders used as a reference for my inspiration and implementations.
 
  What was my goal? The idea behind this game was to attempt and replicate space invaders, but I decided to use some of the game's mechanics as my inspiration, while adding score, a health bar , and the ability to move around with the UP, DOWN, LEFT, RIGHT arrow keys. However, the shooting mechanics are limited to an upward direction from the “Ship” the user controls when pressing spacebar. 
  My proejct began small with the idea of having the user avoid falling spikes but decided to shift my entire idea and create a shooting game, and slowly build upon that idea and get the game mechanics of shooting and health/damage taken and enemies that I would be shooting at, etc. 
  
  Once my game had it's implementations in place I needed to add sprites images instead of having circle objects in it's place after that I added menu system of start screen, end, and win screen. Lastly this whole game was created in > 1 month time-frame with a programming language I have never used befor for my University's Game Development Course.
  

 
 
