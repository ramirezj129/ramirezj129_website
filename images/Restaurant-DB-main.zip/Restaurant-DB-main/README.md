# Restaurant-DB
Created a Restaurant based Database Management System using MySQL Team Size: 3


Database Video of it's columns and averages.
https://drive.google.com/file/d/1qVbcGNRjohRxJgfvMRJ2klpn4p-FPQN6/view?usp=share_link
